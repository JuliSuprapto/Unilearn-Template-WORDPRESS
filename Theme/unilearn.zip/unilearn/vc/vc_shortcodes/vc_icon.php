<?php
/*	vc_map( array(
		"name"				=> esc_html__( 'CWS Vc Icon', 'unilearn' ),
		"base"				=> "vc_icon",
		'category'			=> "Unilearn VC Shortcodes",
		"weight"			=> 80,
		"params"			=> array(
			array(
				"type"			=> "textfield",
				"admin_label"	=> true,
				"heading"		=> esc_html__( 'Title', 'unilearn' ),
				"param_name"	=> "title",
				"value"			=> ""
			)
		)
	));*/
/*	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_Vc_Icon extends WPBakeryShortCode {
	    }
	}*/
?>