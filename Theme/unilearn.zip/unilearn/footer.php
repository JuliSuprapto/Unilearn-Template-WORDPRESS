		<?php
			get_template_part( "footer_widgets" );
			get_template_part( "footer_copyrights" );
			$scroll_to_top = unilearn_scroll_to_top();
			echo $scroll_to_top;
		?>		
		</div>
		<?php wp_footer(); ?>
	</body>
</html>