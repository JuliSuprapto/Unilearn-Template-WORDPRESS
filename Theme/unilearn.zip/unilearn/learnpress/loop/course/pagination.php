<?php
/**
 * Pagination
 *
 * @author 		ThimPress
 * @package 	LearnPress/Templates
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $wp_query;

if ( $wp_query->max_num_pages <= 1 ) {
	return;
}
?>
<nav class="pagination">
	<div class='page_links'>
	<?php
		echo paginate_links( apply_filters( 'learn_press_pagination_args', array(
			'base'         => esc_url_raw( str_replace( 999999999, '%#%', get_pagenum_link( 999999999, false ) ) ),
			'format'       => '',
			'current'      => max( 1, get_query_var( 'paged' ) ),
			'total'        => $wp_query->max_num_pages,
			'prev_text'    => "<i class='fa fa-angle-left'></i>",
			'next_text'    => "<i class='fa fa-angle-right'></i>",
			'mid_size'     => 2
		)));
	?>
	</div>
</nav>