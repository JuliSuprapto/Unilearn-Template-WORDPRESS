<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */
defined('ABSPATH') || exit();
ob_start();
the_excerpt();
$excerpt = ob_get_clean();
if ( !empty( $excerpt ) ){
	?>
	<div class="course-introduce">
		<?php echo $excerpt; ?>
	</div>
<?php
}
