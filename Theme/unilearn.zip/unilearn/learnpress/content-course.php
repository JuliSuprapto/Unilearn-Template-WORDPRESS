<?php
/**
 * Template for displaying course content within the loop
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 1.0
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php
		ob_start();
		do_action( 'unilearn_lp_courses_loop_item_styles' );
		$styles = ob_get_clean();
		if ( !empty( $styles ) ){
			echo "<style type='text/css' scoped>$styles</style>";
		}
	?>

	<div class='post_wrapper lp_course_post_wrapper posts_grid_post_wrapper'>
	
	<?php do_action( 'learn_press_before_courses_loop_item' ); ?>

	<?php do_action( 'learn_press_after_courses_loop_item' ); ?>
	
	</div>
</div>