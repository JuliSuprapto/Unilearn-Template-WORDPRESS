<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       2.1.5
 */
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$page_classes 		= "";
$sb_layout 			= unilearn_get_option( 'lms-sb-layout' );
$sb_enabled 		= in_array( $sb_layout, array( 'left', 'right', 'both' ) );
$sb1 				= unilearn_get_option( 'lms-sb1' );
$sb2 				= unilearn_get_option( 'lms-sb2' );
$sb1_exists 		= $sb_enabled && is_active_sidebar( $sb1 );
$sb2_exists 		= $sb_enabled && $sb_layout == 'both' && is_active_sidebar( $sb2 );
$sb_exists 			= $sb1_exists || $sb2_exists;
$sb_layout_class 	= "";
if ( $sb1_exists && $sb2_exists ){
	$sb_layout_class = "double_sidebar";
}
else if ( $sb1_exists || $sb2_exists ){
	$sb_layout_class = "single_sidebar";
}
$page_classes .= " $sb_layout_class";
echo "<div id='page'" . ( !empty( $page_classes ) ? " class='" . trim( $page_classes ) . "'" : "" ) . ">";
	echo "<div class='unilearn_layout_container'>";
		if ( $sb1_exists && in_array( $sb_layout, array( "left", "both" ) ) ){
			echo "<ul id='left_sidebar' class='sidebar'>";
				dynamic_sidebar( $sb1 );
			echo "</ul>";
		}
		if ( $sb1_exists && $sb_layout === "right" ){
			echo "<ul id='right_sidebar' class='sidebar'>";
				dynamic_sidebar( $sb1 );
			echo "</ul>";
		}
		else if ( $sb1_exists && $sb2_exists && $sb_layout === "both" ){
			echo "<ul id='right_sidebar' class='sidebar'>";
				dynamic_sidebar( $sb2 );
			echo "</ul>";	
		}
		echo "<main id='page_content'>";
?>