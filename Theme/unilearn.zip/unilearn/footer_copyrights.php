<?php
$copyrights_text = unilearn_get_option( "copyrights_text" );
$social_location = unilearn_get_option( 'social_location' );
$social_links = unilearn_render_social_links ();
$show_social_in_cprs = in_array( $social_location, array( 'bottom', 'both' ) ) && !empty( $social_links );
$is_wpml_active = unilearn_is_wpml_active ();
$show_flags_in_footer = unilearn_show_flags_in_footer ();
if ( !empty( $copyrights_text ) || $show_social_in_cprs ){
	echo "<footer id='site_footer'>";
		echo "<div class='unilearn_layout_container clearfix'>";
			if ( $is_wpml_active && $show_flags_in_footer ){
				echo "<div id='footer_icl'>";
					do_action( 'icl_language_selector' );
				echo "</div>";
			}
			echo $show_social_in_cprs ? "<div id='footer_social' class='unilearn_social'>" . wp_kses( $social_links, array(
				'a' 	=> array(
			    	'class'	=> array(),					
				    'href'	=> array(),
				    'title' => array()
			    ),
			    'i' 	=> array(
			    	'class'	=> array()
			    )
			)) . "</div>" : "";
			echo !empty( $copyrights_text ) ? "<div id='site_copyrights'>" . wp_kses( $copyrights_text, array(
				'a' 	=> array(
				    'href'	=> array(),
				    'title' => array()
			    ),
			    'span' 	=> array(),
			    'i' 	=> array(
			    	'class'	=> array()
			    ),
			    'br' 	=> array(),
			    'em' 	=> array(),
			    'strong'=> array(),
			)) . "</div>" : "";
		echo "</div>";
	echo "</footer>";
}
?>